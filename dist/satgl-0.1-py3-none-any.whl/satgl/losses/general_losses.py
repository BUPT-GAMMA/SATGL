# import torch

# def mse_loss(pred, target):
#     return torch.mean((pred - target) ** 2)

# def mae_loss(pred, target):
#     return torch.mean(torch.abs(pred - target))

# def cross_entropy_loss(pred, target):
#     return torch.nn.functional.cross_entropy(pred, target)

# def binary_cross_entropy_loss(pred, target):
#     return torch.nn.functional.binary_cross_entropy(pred, target)

# def nll_loss(pred, target):
#     return torch.nn.functional.nll_loss(pred, target)

# def kl_div_loss(pred, target):
#     return torch.nn.functional.kl_div(pred, target)
